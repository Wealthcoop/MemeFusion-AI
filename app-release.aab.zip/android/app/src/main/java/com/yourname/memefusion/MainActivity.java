package com.yourname.memefusion;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
